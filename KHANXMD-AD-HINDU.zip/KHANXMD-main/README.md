# KHAN-MD — AD HINDU Edition

Owner/developer display name has been changed to **AD HINDU**.

## Important deployment note

This project is a persistent WhatsApp bot (Baileys). **Vercel is not suitable for running the bot process continuously**, because Vercel serverless functions are not designed to keep a WhatsApp WebSocket connection alive.

Recommended layout:
- **GitHub:** store the source code.
- **Render/Railway/another persistent Node host:** run the WhatsApp bot.
- **Vercel:** optionally host a web page, API, or dashboard separately.

## Configuration

Set these environment variables on the host:
- `OWNER_NAME=AD HINDU`
- `OWNER_NUMBER=YOUR_NUMBER_WITHOUT_PLUS`
- `SESSION_ID=YOUR_SESSION_VALUE` (if this project requires it)
- `PREFIX=.`

Do not commit session credentials or secrets to GitHub.

## Local test

```bash
npm install
npm start
```
